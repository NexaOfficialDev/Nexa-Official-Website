Nexa 1.0.0 — Source + Build Package

This package contains the Nexa compiler/runtime source, website source, and Windows build scripts.
It intentionally excludes old 0.9.6 EXE/MSI binaries. Build fresh 1.0.0 artifacts using
BUILD-RELEASE.txt and BUILD-INSTALLERS.txt.

Formats: .nx (source), .nxw (website source), .nxa (application project)
Windows file icon policy: Nexa branding is associated with .nx and .nxw only.
.nxa is intentionally not registered or assigned a Nexa icon; app creators can use their own icons.

Installer defaults: C:\Nexa\nex32 and C:\Nexa\nex64
