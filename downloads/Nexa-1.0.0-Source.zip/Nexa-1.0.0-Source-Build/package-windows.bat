@echo off
setlocal
rem Use the installer builder that skips x64 cleanly when no x64 toolchain is installed.
call "%~dp0build-all-installers.bat"
exit /b %errorlevel%
