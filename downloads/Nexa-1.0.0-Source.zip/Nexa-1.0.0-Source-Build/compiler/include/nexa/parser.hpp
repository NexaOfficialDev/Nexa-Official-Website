#ifndef NEXA_PARSER_HPP
#define NEXA_PARSER_HPP

#include <vector>
#include <string>

#include "nexa/token.hpp"
#include "nexa/ast.hpp"

namespace nexa {

class Parser {
public:
    explicit Parser(
        const std::vector<Token>& tokens
    );

    Program parse();

private:
    std::vector<Token> tokens;
    size_t current;

    const Token& peek() const;
    const Token& previous() const;

    bool check(TokenType type) const;
    bool match(TokenType type);
    const Token& advance();

    void consume(
        TokenType type,
        const std::string& message
    );

    void skipNewlines();

    StmtPtr parseStatement();

    StmtPtr parseLet();
    StmtPtr parseIf();
    StmtPtr parseWhile();
    StmtPtr parseRepeat();
    StmtPtr parseFunction();
    StmtPtr parseReturn();

    std::vector<StmtPtr> parseBlock(
        TokenType stop1,
        TokenType stop2 = TokenType::EndOfFile
    );

    ExprPtr parseExpression();
    ExprPtr parseOr();
    ExprPtr parseAnd();
    ExprPtr parseEquality();
    ExprPtr parseComparison();
    ExprPtr parseTerm();
    ExprPtr parseFactor();
    ExprPtr parseUnary();
    ExprPtr parseCall();
    ExprPtr parsePrimary();

    ExprPtr parseList();

    std::vector<ExprPtr> parseArguments();
};

}

#endif