#ifndef NEXA_AST_HPP
#define NEXA_AST_HPP

#include <memory>
#include <string>
#include <vector>

namespace nexa {

struct Expression {
    virtual ~Expression() {}
};

using ExprPtr = std::shared_ptr<Expression>;

struct LiteralExpression : Expression {
    enum class Kind {
        Number,
        String,
        Boolean,
        Null
    };

    Kind kind;
    double numberValue;
    std::string stringValue;
    bool booleanValue;

    LiteralExpression();
};

struct IdentifierExpression : Expression {
    std::string name;

    explicit IdentifierExpression(
        const std::string& name
    );
};

struct ListExpression : Expression {
    std::vector<ExprPtr> elements;
};

struct UnaryExpression : Expression {
    std::string op;
    ExprPtr operand;

    UnaryExpression(
        const std::string& op,
        ExprPtr operand
    );
};

struct BinaryExpression : Expression {
    std::string op;
    ExprPtr left;
    ExprPtr right;

    BinaryExpression(
        const std::string& op,
        ExprPtr left,
        ExprPtr right
    );
};

struct FunctionCallExpression : Expression {
    std::string name;
    std::vector<ExprPtr> arguments;

    explicit FunctionCallExpression(
        const std::string& name
    );
};

struct IndexExpression : Expression {
    ExprPtr object;
    ExprPtr index;

    IndexExpression(
        ExprPtr object,
        ExprPtr index
    );
};

struct Statement {
    virtual ~Statement() {}
};

using StmtPtr = std::shared_ptr<Statement>;

struct ExpressionStatement : Statement {
    ExprPtr expression;

    explicit ExpressionStatement(
        ExprPtr expression
    );
};

struct LetStatement : Statement {
    std::string name;
    ExprPtr value;

    LetStatement(
        const std::string& name,
        ExprPtr value
    );
};

struct AssignmentStatement : Statement {
    std::string name;
    ExprPtr value;

    AssignmentStatement(
        const std::string& name,
        ExprPtr value
    );
};

struct IfStatement : Statement {
    ExprPtr condition;
    std::vector<StmtPtr> thenBranch;
    std::vector<StmtPtr> elseBranch;
};

struct WhileStatement : Statement {
    ExprPtr condition;
    std::vector<StmtPtr> body;
};

struct RepeatStatement : Statement {
    ExprPtr count;
    std::vector<StmtPtr> body;
};

struct BreakStatement : Statement {
};

struct ContinueStatement : Statement {
};

struct ReturnStatement : Statement {
    ExprPtr value;
};

struct FunctionStatement : Statement {
    std::string name;
    std::vector<std::string> parameters;
    std::vector<StmtPtr> body;
};

struct Program {
    std::vector<StmtPtr> statements;
};

}

#endif