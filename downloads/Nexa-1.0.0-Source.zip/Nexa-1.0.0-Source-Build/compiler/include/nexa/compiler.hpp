#ifndef NEXA_COMPILER_HPP
#define NEXA_COMPILER_HPP

#include <string>

#include "nexa/diagnostics.hpp"

namespace nexa {

class Compiler {
public:
    Compiler();

    bool compileSource(
        const std::string& source,
        std::string& output
    );

    bool compileFile(
        const std::string& filename,
        std::string& output
    );

    const Diagnostics& getDiagnostics() const;

private:
    Diagnostics diagnostics;

    bool readFile(
        const std::string& filename,
        std::string& source
    );
};

}

#endif