#ifndef NEXA_TOKEN_HPP
#define NEXA_TOKEN_HPP

#include <string>

namespace nexa {

enum class TokenType {
    EndOfFile,

    Identifier,
    Number,
    String,

    Let,
    If,
    Else,
    End,
    While,
    Repeat,
    Function,
    Return,
    Break,
    Continue,

    True,
    False,
    Null,

    And,
    Or,
    Not,

    Plus,
    Minus,
    Star,
    Slash,
    Percent,

    Equal,
    EqualEqual,
    NotEqual,

    Less,
    LessEqual,
    Greater,
    GreaterEqual,

    LeftParen,
    RightParen,
    LeftBracket,
    RightBracket,
    Comma,

    Newline
};

struct Token {
    TokenType type;
    std::string text;
    double number;
    int line;
    int column;

    Token(
        TokenType type,
        const std::string& text,
        int line,
        int column,
        double number = 0.0
    );
};

const char* tokenTypeName(TokenType type);

}

#endif