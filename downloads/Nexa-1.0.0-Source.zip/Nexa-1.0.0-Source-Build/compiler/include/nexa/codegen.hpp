#ifndef NEXA_CODEGEN_HPP
#define NEXA_CODEGEN_HPP

#include <string>
#include <vector>

#include "nexa/ast.hpp"

namespace nexa {

class CodeGenerator {
public:
    CodeGenerator();

    std::string generate(
        const Program& program
    );

private:
    std::string output;
    int indent;
    int loopDepth;
    int functionDepth;

    void emit(const std::string& text);
    void emitLine(const std::string& text);

    void generateProgram(
        const Program& program
    );

    void generateFunction(
        const FunctionStatement& function
    );

    void generateStatement(
        const StmtPtr& statement
    );

    void generateStatements(
        const std::vector<StmtPtr>& statements
    );

    std::string generateExpression(
        const ExprPtr& expression
    );

    std::string escapeString(
        const std::string& value
    );

    std::string functionName(
        const std::string& name
    );
};

}

#endif