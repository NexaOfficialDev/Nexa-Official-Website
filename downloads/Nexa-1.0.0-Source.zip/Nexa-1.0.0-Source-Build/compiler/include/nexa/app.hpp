#ifndef NEXA_APP_HPP
#define NEXA_APP_HPP

#include <string>

namespace nexa {
namespace app {

bool compileFile(const std::string& filename, std::string& output, std::string& error);

}
}

#endif
