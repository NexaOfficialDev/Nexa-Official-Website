#ifndef NEXA_DIAGNOSTICS_HPP
#define NEXA_DIAGNOSTICS_HPP

#include <string>
#include <vector>

namespace nexa {

enum class DiagnosticSeverity {
    Info,
    Warning,
    Error
};

struct Diagnostic {
    DiagnosticSeverity severity;
    std::string code;
    std::string message;
    int line;
    int column;

    Diagnostic(
        DiagnosticSeverity severity,
        const std::string& code,
        const std::string& message,
        int line,
        int column
    );
};

class Diagnostics {
public:
    void info(
        const std::string& code,
        const std::string& message,
        int line = 0,
        int column = 0
    );

    void warning(
        const std::string& code,
        const std::string& message,
        int line = 0,
        int column = 0
    );

    void error(
        const std::string& code,
        const std::string& message,
        int line = 0,
        int column = 0
    );

    bool hasErrors() const;

    size_t count() const;

    void clear();

    void print() const;

private:
    std::vector<Diagnostic> diagnostics;
};

const char* severityName(
    DiagnosticSeverity severity
);

}

#endif