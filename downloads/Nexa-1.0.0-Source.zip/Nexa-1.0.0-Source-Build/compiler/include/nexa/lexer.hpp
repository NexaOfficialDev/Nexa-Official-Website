#ifndef NEXA_LEXER_HPP
#define NEXA_LEXER_HPP

#include <string>
#include <vector>

#include "nexa/token.hpp"

namespace nexa {

class Lexer {
public:
    explicit Lexer(const std::string& source);

    std::vector<Token> tokenize();

private:
    std::string source;
    size_t position;
    int line;
    int column;

    char current() const;
    char peek(size_t offset = 1) const;

    void advance();
    void skipSpaces();

    Token makeToken(
        TokenType type,
        const std::string& text,
        int tokenLine,
        int tokenColumn
    );

    Token readNumber();
    Token readString();
    Token readIdentifier();

    TokenType keywordType(const std::string& text) const;
};

}

#endif
