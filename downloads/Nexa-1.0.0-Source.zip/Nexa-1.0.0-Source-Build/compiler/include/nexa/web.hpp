#ifndef NEXA_WEB_HPP
#define NEXA_WEB_HPP

#include <string>

namespace nexa { namespace web {
    bool compileFile(const std::string& filename, std::string& output, std::string& error);
}}

#endif
