#include "nexa/compiler.hpp"

#include <fstream>
#include <sstream>
#include <stdexcept>

#include "nexa/codegen.hpp"
#include "nexa/lexer.hpp"
#include "nexa/parser.hpp"

namespace nexa {

Compiler::Compiler() {
}

bool Compiler::readFile(
    const std::string& filename,
    std::string& source
) {
    std::ifstream file(
        filename.c_str(),
        std::ios::in | std::ios::binary
    );

    if (!file) {
        diagnostics.error(
            "NX001",
            "Could not open source file: " +
            filename
        );

        return false;
    }

    std::ostringstream stream;
    stream << file.rdbuf();

    source = stream.str();

    return true;
}

bool Compiler::compileSource(
    const std::string& source,
    std::string& output
) {
    diagnostics.clear();
    output.clear();

    try {
        Lexer lexer(source);

        std::vector<Token> tokens =
            lexer.tokenize();

        Parser parser(tokens);

        Program program =
            parser.parse();

        CodeGenerator generator;

        output =
            generator.generate(program);

        return true;
    }
    catch (const std::exception& e) {
        diagnostics.error(
            "NX200",
            e.what()
        );

        return false;
    }
}

bool Compiler::compileFile(
    const std::string& filename,
    std::string& output
) {
    std::string source;

    if (!readFile(filename, source)) {
        return false;
    }

    return compileSource(
        source,
        output
    );
}

const Diagnostics& Compiler::getDiagnostics() const {
    return diagnostics;
}

}