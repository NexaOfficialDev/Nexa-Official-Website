#include "nexa/token.hpp"

namespace nexa {

Token::Token(
    TokenType type,
    const std::string& text,
    int line,
    int column,
    double number
)
    : type(type),
      text(text),
      number(number),
      line(line),
      column(column) {
}

const char* tokenTypeName(TokenType type) {
    switch (type) {
        case TokenType::EndOfFile: return "end of file";
        case TokenType::Identifier: return "identifier";
        case TokenType::Number: return "number";
        case TokenType::String: return "string";

        case TokenType::Let: return "let";
        case TokenType::If: return "if";
        case TokenType::Else: return "else";
        case TokenType::End: return "end";
        case TokenType::While: return "while";
        case TokenType::Repeat: return "repeat";
        case TokenType::Function: return "function";
        case TokenType::Return: return "return";
        case TokenType::Break: return "break";
        case TokenType::Continue: return "continue";

        case TokenType::True: return "true";
        case TokenType::False: return "false";
        case TokenType::Null: return "null";

        case TokenType::And: return "and";
        case TokenType::Or: return "or";
        case TokenType::Not: return "not";

        case TokenType::Plus: return "+";
        case TokenType::Minus: return "-";
        case TokenType::Star: return "*";
        case TokenType::Slash: return "/";
        case TokenType::Percent: return "%";

        case TokenType::Equal: return "=";
        case TokenType::EqualEqual: return "==";
        case TokenType::NotEqual: return "!=";

        case TokenType::Less: return "<";
        case TokenType::LessEqual: return "<=";
        case TokenType::Greater: return ">";
        case TokenType::GreaterEqual: return ">=";

        case TokenType::LeftParen: return "(";
        case TokenType::RightParen: return ")";
        case TokenType::LeftBracket: return "[";
        case TokenType::RightBracket: return "]";
        case TokenType::Comma: return ",";
        case TokenType::Newline: return "newline";
    }

    return "unknown";
}

}