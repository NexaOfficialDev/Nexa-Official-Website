#include "nexa/app.hpp"

#include <cctype>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace nexa { namespace app {

struct Element { std::string kind, id, text; int x, y, w, h; };
struct Handler { std::string event, target, action, arg1, arg2; };

static std::string trim(const std::string& s) {
    size_t a = 0; while (a < s.size() && std::isspace((unsigned char)s[a])) ++a;
    size_t b = s.size(); while (b > a && std::isspace((unsigned char)s[b-1])) --b;
    return s.substr(a, b-a);
}
static std::string quoted(const std::string& line, size_t& p) {
    while (p < line.size() && std::isspace((unsigned char)line[p])) ++p;
    if (p >= line.size() || line[p] != '"') throw std::runtime_error("expected quoted string");
    ++p; std::string out;
    while (p < line.size()) { char c=line[p++]; if(c=='"') return out; if(c=='\\' && p<line.size()){char n=line[p++]; if(n=='n')out+='\n'; else if(n=='t')out+='\t'; else out+=n;} else out+=c; }
    throw std::runtime_error("unterminated quoted string");
}
static int integer(const std::string& line, size_t& p) {
    while(p<line.size() && std::isspace((unsigned char)line[p])) ++p;
    size_t start=p; if(p<line.size() && (line[p]=='-'||line[p]=='+')) ++p;
    while(p<line.size() && std::isdigit((unsigned char)line[p])) ++p;
    if(start==p || (p==start+1 && (line[start]=='-'||line[start]=='+'))) throw std::runtime_error("expected integer");
    return std::atoi(line.substr(start,p-start).c_str());
}
static std::string cpp(const std::string& s) {
    std::string o="L\""; for(size_t i=0;i<s.size();++i){ unsigned char c=(unsigned char)s[i]; if(c=='\\')o+="\\\\"; else if(c=='"')o+="\\\""; else if(c=='\n')o+="\\n"; else if(c=='\r')o+="\\r"; else o+=(char)c; } o+='"'; return o;
}
static std::string lower(std::string s) { for(size_t i=0;i<s.size();++i)s[i]=(char)std::tolower((unsigned char)s[i]); return s; }

bool compileFile(const std::string& filename, std::string& output, std::string& error) {
    std::ifstream f(filename.c_str(), std::ios::binary); if(!f){error="Could not open Nexa App file: "+filename;return false;}
    std::ostringstream ss; ss<<f.rdbuf(); std::istringstream in(ss.str());
    std::string title="Nexa App", mode="gui", iconPath=""; int ww=800,hh=500; std::vector<Element> els; std::vector<Handler> hs; bool started=false, ended=false;
    std::string line; int ln=0;
    while(std::getline(in,line)) { ++ln; line=trim(line); if(line.empty()||line[0]=='#')continue; size_t p=0; std::string cmd; while(p<line.size()&&!std::isspace((unsigned char)line[p]))cmd+=line[p++];
        try {
            if(cmd=="app"){title=quoted(line,p);started=true;}
            else if(cmd=="type"){mode=quoted(line,p);if(mode!="gui")throw std::runtime_error("only type \"gui\" is supported in 1.0.0");}
            else if(cmd=="icon"){
                while(p<line.size() && std::isspace((unsigned char)line[p])) ++p;
                if(p<line.size() && line[p]=='=') ++p;
                while(p<line.size() && std::isspace((unsigned char)line[p])) ++p;
                if(p<line.size() && line[p]=='"') iconPath=quoted(line,p);
                else { iconPath=trim(line.substr(p)); if(iconPath.empty()) throw std::runtime_error("expected icon path"); }
            }
            else if(cmd=="window"){title=quoted(line,p);ww=integer(line,p);hh=integer(line,p);}
            else if(cmd=="text"){Element e;e.kind=cmd;e.id=quoted(line,p);e.text=e.id;e.x=integer(line,p);e.y=integer(line,p);e.w=integer(line,p);e.h=integer(line,p);els.push_back(e);}
            else if(cmd=="button"||cmd=="input"){
                Element e;e.kind=cmd;e.id=quoted(line,p);
                if(cmd=="button") { e.text=e.id; e.x=integer(line,p); e.y=integer(line,p); e.w=integer(line,p); e.h=integer(line,p); }
                else { e.text=quoted(line,p); e.x=integer(line,p); e.y=integer(line,p); e.w=integer(line,p); e.h=integer(line,p); }
                els.push_back(e);
            }
            else if(cmd=="on"){
                Handler h; std::string first=quoted(line,p); std::string second;
                if(p<line.size()) second=quoted(line,p);
                if(first=="startup" || first=="close") { h.event=first; h.action=second; if(h.action=="message"||h.action=="open"||h.action=="run"||h.action=="clipboard") h.arg1=quoted(line,p); }
                else if(lower(first)=="click") { h.event="click"; h.target=second; h.action=quoted(line,p); if(h.action=="message"||h.action=="open"||h.action=="run"||h.action=="clipboard") h.arg1=quoted(line,p); else if(h.action=="set") { h.arg1=quoted(line,p); h.arg2=quoted(line,p); } }
                else { h.event="click"; h.target=first; h.action=second; if(h.action=="message"||h.action=="open"||h.action=="run"||h.action=="clipboard") h.arg1=quoted(line,p); else if(h.action=="set") { h.arg1=quoted(line,p); h.arg2=quoted(line,p); } }
                hs.push_back(h);
            }
            else if(cmd=="end"){ended=true;break;}
            else throw std::runtime_error("unknown Nexa App command: "+cmd);
        } catch(const std::exception&e){std::ostringstream m;m<<"NXA"<<(100+ln)<<": "<<e.what();error=m.str();return false;}
    }
    if(!started){error="NXA101: Nexa App file must contain app \"Title\".";return false;}
    if(!ended){error="NXA102: Nexa App file must end with 'end'.";return false;}
    std::ostringstream o;
    o << "#include <windows.h>\n#include <shellapi.h>\n#include <string>\n#include <cstring>\n\n"
      << "static HINSTANCE g_instance; static HWND g_controls[256]; static int g_count=0;\n"
      << "static HWND g_window; static HICON g_icon=0;\n"
      << "static void msg(const wchar_t* s){MessageBoxW(g_window,s," << cpp(title) << ",MB_OK|MB_ICONINFORMATION);}\n"
      << "static void set_control(const wchar_t* id,const wchar_t* value){ for(int i=0;i<g_count;i++){ if((LPCWSTR)GetPropW(g_controls[i],L\"nexa_id\") && lstrcmpW((LPCWSTR)GetPropW(g_controls[i],L\"nexa_id\"),id)==0) SetWindowTextW(g_controls[i],value); }}\n"
      << "static LRESULT CALLBACK WndProc(HWND h,UINT m,WPARAM w,LPARAM l){\n"
      << " if(m==WM_CREATE){ g_window=h;\n";
    for(size_t i=0;i<hs.size();++i) if(hs[i].event=="startup") {
        if(hs[i].action=="message") o << "  msg("<<cpp(hs[i].arg1)<<");\n";
        else if(hs[i].action=="open") o << "  ShellExecuteW(h,L\"open\","<<cpp(hs[i].arg1)<<",0,0,SW_SHOWNORMAL);\n";
        else if(hs[i].action=="run") o << "  ShellExecuteW(h,L\"open\",L\"cmd.exe\",L\"/C "<<hs[i].arg1<<"\",0,SW_HIDE);\n";
        else if(hs[i].action=="clipboard") o << "  OpenClipboard(h); EmptyClipboard(); { size_t n=(wcslen("<<cpp(hs[i].arg1)<<")+1)*sizeof(wchar_t); HGLOBAL hg=GlobalAlloc(GMEM_MOVEABLE,n); memcpy(GlobalLock(hg),"<<cpp(hs[i].arg1)<<",n); GlobalUnlock(hg); SetClipboardData(CF_UNICODETEXT,hg); } CloseClipboard();\n";
    }
    if(!iconPath.empty()) o << "  g_icon=(HICON)LoadImageW(0,"<<cpp(iconPath)<<",IMAGE_ICON,32,32,LR_LOADFROMFILE|LR_DEFAULTSIZE); if(g_icon){SendMessageW(h,WM_SETICON,ICON_BIG,(LPARAM)g_icon);SendMessageW(h,WM_SETICON,ICON_SMALL,(LPARAM)g_icon);}";
    o << "  }\n if(m==WM_COMMAND){int id=LOWORD(w); switch(id){\n";
    for(size_t i=0;i<hs.size();++i){
        if(hs[i].event!="click") continue;
        int id=1000+(int)i;
        o << "  case "<<id<<": ";
        if(hs[i].action=="message") o << "msg("<<cpp(hs[i].arg1)<<"); break;";
        else if(hs[i].action=="open") o << "ShellExecuteW(h,L\"open\","<<cpp(hs[i].arg1)<<",0,0,SW_SHOWNORMAL); break;";
        else if(hs[i].action=="run") o << "ShellExecuteW(h,L\"open\",L\"cmd.exe\",L\"/C "<<hs[i].arg1<<"\",0,SW_HIDE); break;";
        else if(hs[i].action=="clipboard") o << "OpenClipboard(h); EmptyClipboard(); { size_t n=(wcslen("<<cpp(hs[i].arg1)<<")+1)*sizeof(wchar_t); HGLOBAL hg=GlobalAlloc(GMEM_MOVEABLE,n); memcpy(GlobalLock(hg),"<<cpp(hs[i].arg1)<<",n); GlobalUnlock(hg); SetClipboardData(CF_UNICODETEXT,hg); } CloseClipboard(); break;";
        else if(hs[i].action=="set") o << "set_control("<<cpp(hs[i].arg1)<<","<<cpp(hs[i].arg2)<<"); break;";
        else o << "break;";
        o << "\n";
    }
    o << " }}\n if(m==WM_DESTROY){\n";
    for(size_t i=0;i<hs.size();++i) if(hs[i].event=="close") {
        if(hs[i].action=="message") o << "  msg("<<cpp(hs[i].arg1)<<");\n";
    }
    o << " PostQuitMessage(0);return 0;} return DefWindowProcW(h,m,w,l);}\n"
      << "int WINAPI wWinMain(HINSTANCE hi,HINSTANCE,LPWSTR, int show){g_instance=hi; WNDCLASSW wc={0};wc.lpfnWndProc=WndProc;wc.hInstance=hi;wc.hCursor=LoadCursor(0,IDC_ARROW);wc.lpszClassName=L\"NexaApp\";RegisterClassW(&wc);"
      << "HWND h=CreateWindowExW(0,L\"NexaApp\","<<cpp(title)<<",WS_OVERLAPPEDWINDOW,CW_USEDEFAULT,CW_USEDEFAULT,"<<ww<<","<<hh<<",0,0,hi,0); g_window=h;\n"
      << "ShowWindow(h,show); UpdateWindow(h);\n";
    for(size_t i=0;i<els.size();++i){
        const Element&e=els[i]; std::string cls=e.kind=="button"?"BUTTON":(e.kind=="input"?"EDIT":"STATIC"); std::string style=e.kind=="button"?"WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON":(e.kind=="input"?"WS_CHILD|WS_VISIBLE|WS_BORDER|ES_AUTOHSCROLL":"WS_CHILD|WS_VISIBLE");
        int id=0; if(e.kind=="button"){ for(size_t j=0;j<hs.size();++j) if(hs[j].event=="click"&&hs[j].target==e.id){id=1000+(int)j;break;} }
        o<<"{ HWND c=CreateWindowW(L\""<<cls<<"\","<<cpp(e.text)<<",("<<style<<"),"<<e.x<<","<<e.y<<","<<e.w<<","<<e.h<<",h,"<<id<<",hi,0); if(c){ SetPropW(c,L\"nexa_id\",(HANDLE)"<<cpp(e.id)<<"); g_controls[g_count++]=c; }}\n";
    }
    o << "MSG msgm; while(GetMessageW(&msgm,0,0,0)>0){TranslateMessage(&msgm);DispatchMessageW(&msgm);} return (int)msgm.wParam;}\n";
    output=o.str(); return true;
}

}} // namespace nexa::app
