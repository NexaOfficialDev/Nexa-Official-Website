#include "nexa/parser.hpp"

#include <memory>
#include <stdexcept>

namespace nexa {

Parser::Parser(
    const std::vector<Token>& tokens
)
    : tokens(tokens),
      current(0) {
}

const Token& Parser::peek() const {
    return tokens[current];
}

const Token& Parser::previous() const {
    return tokens[current - 1];
}

bool Parser::check(TokenType type) const {
    return peek().type == type;
}

bool Parser::match(TokenType type) {
    if (!check(type)) {
        return false;
    }

    advance();
    return true;
}

const Token& Parser::advance() {
    if (current < tokens.size() - 1) {
        current++;
    }

    return previous();
}

void Parser::consume(
    TokenType type,
    const std::string& message
) {
    if (check(type)) {
        advance();
        return;
    }

    throw std::runtime_error(message);
}

void Parser::skipNewlines() {
    while (match(TokenType::Newline)) {
    }
}

Program Parser::parse() {
    Program program;

    skipNewlines();

    while (!check(TokenType::EndOfFile)) {
        program.statements.push_back(
            parseStatement()
        );

        skipNewlines();
    }

    return program;
}

StmtPtr Parser::parseStatement() {
    if (match(TokenType::Let)) {
        return parseLet();
    }

    if (match(TokenType::If)) {
        return parseIf();
    }

    if (match(TokenType::While)) {
        return parseWhile();
    }

    if (match(TokenType::Repeat)) {
        return parseRepeat();
    }

    if (match(TokenType::Function)) {
        return parseFunction();
    }

    if (match(TokenType::Return)) {
        return parseReturn();
    }

    if (match(TokenType::Break)) {
        return StmtPtr(new BreakStatement());
    }

    if (match(TokenType::Continue)) {
        return StmtPtr(new ContinueStatement());
    }

    if (check(TokenType::Identifier) &&
        current + 1 < tokens.size() &&
        tokens[current + 1].type == TokenType::Equal) {

        std::string name = advance().text;

        advance();

        ExprPtr value = parseExpression();

        return StmtPtr(
            new AssignmentStatement(name, value)
        );
    }

    ExprPtr expression = parseExpression();

    return StmtPtr(
        new ExpressionStatement(expression)
    );
}

StmtPtr Parser::parseLet() {
    consume(
        TokenType::Identifier,
        "Expected variable name after 'let'."
    );

    std::string name = previous().text;

    consume(
        TokenType::Equal,
        "Expected '=' after variable name."
    );

    ExprPtr value = parseExpression();

    return StmtPtr(
        new LetStatement(name, value)
    );
}

StmtPtr Parser::parseIf() {
    ExprPtr condition = parseExpression();

    skipNewlines();

    std::vector<StmtPtr> thenBranch =
        parseBlock(
            TokenType::Else,
            TokenType::End
        );

    std::vector<StmtPtr> elseBranch;

    if (match(TokenType::Else)) {
        skipNewlines();

        elseBranch =
            parseBlock(TokenType::End);
    }

    consume(
        TokenType::End,
        "Expected 'end' after if statement."
    );

    IfStatement* statement = new IfStatement();

    statement->condition = condition;
    statement->thenBranch = thenBranch;
    statement->elseBranch = elseBranch;

    return StmtPtr(statement);
}

StmtPtr Parser::parseWhile() {
    ExprPtr condition = parseExpression();

    skipNewlines();

    std::vector<StmtPtr> body =
        parseBlock(TokenType::End);

    consume(
        TokenType::End,
        "Expected 'end' after while statement."
    );

    WhileStatement* statement =
        new WhileStatement();

    statement->condition = condition;
    statement->body = body;

    return StmtPtr(statement);
}

StmtPtr Parser::parseRepeat() {
    ExprPtr count = parseExpression();

    skipNewlines();

    std::vector<StmtPtr> body =
        parseBlock(TokenType::End);

    consume(
        TokenType::End,
        "Expected 'end' after repeat statement."
    );

    RepeatStatement* statement =
        new RepeatStatement();

    statement->count = count;
    statement->body = body;

    return StmtPtr(statement);
}

StmtPtr Parser::parseFunction() {
    consume(
        TokenType::Identifier,
        "Expected function name."
    );

    std::string name = previous().text;

    consume(
        TokenType::LeftParen,
        "Expected '(' after function name."
    );

    std::vector<std::string> parameters;

    if (!check(TokenType::RightParen)) {
        do {
            consume(
                TokenType::Identifier,
                "Expected parameter name."
            );

            parameters.push_back(previous().text);

        } while (match(TokenType::Comma));
    }

    consume(
        TokenType::RightParen,
        "Expected ')' after parameters."
    );

    skipNewlines();

    std::vector<StmtPtr> body =
        parseBlock(TokenType::End);

    consume(
        TokenType::End,
        "Expected 'end' after function."
    );

    FunctionStatement* statement =
        new FunctionStatement();

    statement->name = name;
    statement->parameters = parameters;
    statement->body = body;

    return StmtPtr(statement);
}

StmtPtr Parser::parseReturn() {
    ReturnStatement* statement =
        new ReturnStatement();

    if (check(TokenType::Newline) ||
        check(TokenType::EndOfFile) ||
        check(TokenType::End)) {

        statement->value = ExprPtr();
    } else {
        statement->value = parseExpression();
    }

    return StmtPtr(statement);
}

std::vector<StmtPtr> Parser::parseBlock(
    TokenType stop1,
    TokenType stop2
) {
    std::vector<StmtPtr> statements;

    skipNewlines();

    while (!check(stop1) &&
           !check(stop2) &&
           !check(TokenType::EndOfFile)) {

        statements.push_back(
            parseStatement()
        );

        skipNewlines();
    }

    return statements;
}

ExprPtr Parser::parseExpression() {
    return parseOr();
}

ExprPtr Parser::parseOr() {
    ExprPtr expression = parseAnd();

    while (match(TokenType::Or)) {
        ExprPtr right = parseAnd();

        expression = ExprPtr(
            new BinaryExpression(
                "or",
                expression,
                right
            )
        );
    }

    return expression;
}

ExprPtr Parser::parseAnd() {
    ExprPtr expression = parseEquality();

    while (match(TokenType::And)) {
        ExprPtr right = parseEquality();

        expression = ExprPtr(
            new BinaryExpression(
                "and",
                expression,
                right
            )
        );
    }

    return expression;
}

ExprPtr Parser::parseEquality() {
    ExprPtr expression = parseComparison();

    while (check(TokenType::EqualEqual) ||
           check(TokenType::NotEqual)) {

        std::string op = advance().text;

        ExprPtr right = parseComparison();

        expression = ExprPtr(
            new BinaryExpression(
                op,
                expression,
                right
            )
        );
    }

    return expression;
}

ExprPtr Parser::parseComparison() {
    ExprPtr expression = parseTerm();

    while (check(TokenType::Less) ||
           check(TokenType::LessEqual) ||
           check(TokenType::Greater) ||
           check(TokenType::GreaterEqual)) {

        std::string op = advance().text;

        ExprPtr right = parseTerm();

        expression = ExprPtr(
            new BinaryExpression(
                op,
                expression,
                right
            )
        );
    }

    return expression;
}

ExprPtr Parser::parseTerm() {
    ExprPtr expression = parseFactor();

    while (check(TokenType::Plus) ||
           check(TokenType::Minus)) {

        std::string op = advance().text;

        ExprPtr right = parseFactor();

        expression = ExprPtr(
            new BinaryExpression(
                op,
                expression,
                right
            )
        );
    }

    return expression;
}

ExprPtr Parser::parseFactor() {
    ExprPtr expression = parseUnary();

    while (check(TokenType::Star) ||
           check(TokenType::Slash) ||
           check(TokenType::Percent)) {

        std::string op = advance().text;

        ExprPtr right = parseUnary();

        expression = ExprPtr(
            new BinaryExpression(
                op,
                expression,
                right
            )
        );
    }

    return expression;
}

ExprPtr Parser::parseUnary() {
    if (match(TokenType::Minus)) {
        return ExprPtr(
            new UnaryExpression(
                "-",
                parseUnary()
            )
        );
    }

    if (match(TokenType::Not)) {
        return ExprPtr(
            new UnaryExpression(
                "not",
                parseUnary()
            )
        );
    }

    return parseCall();
}

ExprPtr Parser::parseCall() {
    ExprPtr expression = parsePrimary();

    while (true) {
        if (match(TokenType::LeftParen)) {
            IdentifierExpression* identifier =
                dynamic_cast<IdentifierExpression*>(
                    expression.get()
                );

            if (!identifier) {
                throw std::runtime_error(
                    "Only functions can be called."
                );
            }

            FunctionCallExpression* call =
                new FunctionCallExpression(
                    identifier->name
                );

            if (!check(TokenType::RightParen)) {
                call->arguments =
                    parseArguments();
            }

            consume(
                TokenType::RightParen,
                "Expected ')' after arguments."
            );

            expression = ExprPtr(call);
        }
        else if (match(TokenType::LeftBracket)) {
            ExprPtr index = parseExpression();

            consume(
                TokenType::RightBracket,
                "Expected ']' after index."
            );

            expression = ExprPtr(
                new IndexExpression(
                    expression,
                    index
                )
            );
        }
        else {
            break;
        }
    }

    return expression;
}

std::vector<ExprPtr> Parser::parseArguments() {
    std::vector<ExprPtr> arguments;

    do {
        arguments.push_back(
            parseExpression()
        );
    } while (match(TokenType::Comma));

    return arguments;
}

ExprPtr Parser::parsePrimary() {
    if (match(TokenType::Number)) {
        LiteralExpression* literal =
            new LiteralExpression();

        literal->kind =
            LiteralExpression::Kind::Number;

        literal->numberValue =
            previous().number;

        return ExprPtr(literal);
    }

    if (match(TokenType::String)) {
        LiteralExpression* literal =
            new LiteralExpression();

        literal->kind =
            LiteralExpression::Kind::String;

        literal->stringValue =
            previous().text;

        return ExprPtr(literal);
    }

    if (match(TokenType::True)) {
        LiteralExpression* literal =
            new LiteralExpression();

        literal->kind =
            LiteralExpression::Kind::Boolean;

        literal->booleanValue = true;

        return ExprPtr(literal);
    }

    if (match(TokenType::False)) {
        LiteralExpression* literal =
            new LiteralExpression();

        literal->kind =
            LiteralExpression::Kind::Boolean;

        literal->booleanValue = false;

        return ExprPtr(literal);
    }

    if (match(TokenType::Null)) {
        LiteralExpression* literal =
            new LiteralExpression();

        literal->kind =
            LiteralExpression::Kind::Null;

        return ExprPtr(literal);
    }

    if (match(TokenType::Identifier)) {
        return ExprPtr(
            new IdentifierExpression(
                previous().text
            )
        );
    }

    if (match(TokenType::LeftParen)) {
        ExprPtr expression =
            parseExpression();

        consume(
            TokenType::RightParen,
            "Expected ')'."
        );

        return expression;
    }

    if (match(TokenType::LeftBracket)) {
        return parseList();
    }

    throw std::runtime_error(
        "Expected expression."
    );
}

ExprPtr Parser::parseList() {
    ListExpression* list =
        new ListExpression();

    if (!check(TokenType::RightBracket)) {
        do {
            list->elements.push_back(
                parseExpression()
            );
        } while (match(TokenType::Comma));
    }

    consume(
        TokenType::RightBracket,
        "Expected ']' after list."
    );

    return ExprPtr(list);
}

}