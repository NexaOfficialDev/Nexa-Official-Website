#include "nexa/lexer.hpp"

#include <cctype>
#include <cstdlib>
#include <stdexcept>

namespace nexa {

Lexer::Lexer(const std::string& source)
    : source(source),
      position(0),
      line(1),
      column(1) {
}

char Lexer::current() const {
    if (position >= source.size()) {
        return '\0';
    }

    return source[position];
}

char Lexer::peek(size_t offset) const {
    size_t index = position + offset;

    if (index >= source.size()) {
        return '\0';
    }

    return source[index];
}

void Lexer::advance() {
    if (current() == '\n') {
        line++;
        column = 1;
    } else {
        column++;
    }

    position++;
}

void Lexer::skipSpaces() {
    while (current() == ' ' ||
           current() == '\t' ||
           current() == '\r') {
        advance();
    }
}

Token Lexer::makeToken(
    TokenType type,
    const std::string& text,
    int tokenLine,
    int tokenColumn
) {
    return Token(type, text, tokenLine, tokenColumn);
}

TokenType Lexer::keywordType(const std::string& text) const {
    if (text == "let") return TokenType::Let;
    if (text == "if") return TokenType::If;
    if (text == "else") return TokenType::Else;
    if (text == "end") return TokenType::End;
    if (text == "while") return TokenType::While;
    if (text == "repeat") return TokenType::Repeat;
    if (text == "function") return TokenType::Function;
    if (text == "return") return TokenType::Return;
    if (text == "break") return TokenType::Break;
    if (text == "continue") return TokenType::Continue;

    if (text == "true") return TokenType::True;
    if (text == "false") return TokenType::False;
    if (text == "null") return TokenType::Null;

    if (text == "and") return TokenType::And;
    if (text == "or") return TokenType::Or;
    if (text == "not") return TokenType::Not;

    return TokenType::Identifier;
}

Token Lexer::readNumber() {
    int tokenLine = line;
    int tokenColumn = column;

    size_t start = position;
    bool dotSeen = false;

    while (std::isdigit(static_cast<unsigned char>(current())) ||
           current() == '.') {

        if (current() == '.') {
            if (dotSeen) {
                break;
            }

            dotSeen = true;
        }

        advance();
    }

    std::string text = source.substr(start, position - start);

    double value = std::strtod(text.c_str(), 0);

    return Token(
        TokenType::Number,
        text,
        tokenLine,
        tokenColumn,
        value
    );
}

Token Lexer::readString() {
    int tokenLine = line;
    int tokenColumn = column;

    advance();

    std::string value;

    while (current() != '\0' && current() != '"') {
        if (current() == '\\') {
            advance();

            switch (current()) {
                case 'n':
                    value += '\n';
                    break;

                case 't':
                    value += '\t';
                    break;

                case '"':
                    value += '"';
                    break;

                case '\\':
                    value += '\\';
                    break;

                default:
                    value += current();
                    break;
            }

            advance();
            continue;
        }

        value += current();
        advance();
    }

    if (current() != '"') {
        throw std::runtime_error(
            "Unterminated string literal"
        );
    }

    advance();

    return Token(
        TokenType::String,
        value,
        tokenLine,
        tokenColumn
    );
}

Token Lexer::readIdentifier() {
    int tokenLine = line;
    int tokenColumn = column;

    size_t start = position;

    while (std::isalnum(
               static_cast<unsigned char>(current())
           ) ||
           current() == '_') {
        advance();
    }

    std::string text =
        source.substr(start, position - start);

    return makeToken(
        keywordType(text),
        text,
        tokenLine,
        tokenColumn
    );
}

std::vector<Token> Lexer::tokenize() {
    std::vector<Token> tokens;

    while (current() != '\0') {
        skipSpaces();

        if (current() == '\0') {
            break;
        }

        int tokenLine = line;
        int tokenColumn = column;

        char c = current();

        if (c == '#') {
            while (current() != '\0' &&
                   current() != '\n') {
                advance();
            }

            continue;
        }

        if (c == '\n') {
            tokens.push_back(
                makeToken(
                    TokenType::Newline,
                    "\\n",
                    tokenLine,
                    tokenColumn
                )
            );

            advance();
            continue;
        }

        if (std::isdigit(
                static_cast<unsigned char>(c))) {
            tokens.push_back(readNumber());
            continue;
        }

        if (std::isalpha(
                static_cast<unsigned char>(c)) ||
            c == '_') {
            tokens.push_back(readIdentifier());
            continue;
        }

        if (c == '"') {
            tokens.push_back(readString());
            continue;
        }

        switch (c) {
            case '+':
                tokens.push_back(
                    makeToken(TokenType::Plus, "+",
                              tokenLine, tokenColumn));
                advance();
                break;

            case '-':
                tokens.push_back(
                    makeToken(TokenType::Minus, "-",
                              tokenLine, tokenColumn));
                advance();
                break;

            case '*':
                tokens.push_back(
                    makeToken(TokenType::Star, "*",
                              tokenLine, tokenColumn));
                advance();
                break;

            case '/':
                tokens.push_back(
                    makeToken(TokenType::Slash, "/",
                              tokenLine, tokenColumn));
                advance();
                break;

            case '%':
                tokens.push_back(
                    makeToken(TokenType::Percent, "%",
                              tokenLine, tokenColumn));
                advance();
                break;

            case '(':
                tokens.push_back(
                    makeToken(TokenType::LeftParen, "(",
                              tokenLine, tokenColumn));
                advance();
                break;

            case ')':
                tokens.push_back(
                    makeToken(TokenType::RightParen, ")",
                              tokenLine, tokenColumn));
                advance();
                break;

            case '[':
                tokens.push_back(
                    makeToken(TokenType::LeftBracket, "[",
                              tokenLine, tokenColumn));
                advance();
                break;

            case ']':
                tokens.push_back(
                    makeToken(TokenType::RightBracket, "]",
                              tokenLine, tokenColumn));
                advance();
                break;

            case ',':
                tokens.push_back(
                    makeToken(TokenType::Comma, ",",
                              tokenLine, tokenColumn));
                advance();
                break;

            case '=':
                advance();

                if (current() == '=') {
                    advance();

                    tokens.push_back(
                        makeToken(
                            TokenType::EqualEqual,
                            "==",
                            tokenLine,
                            tokenColumn
                        )
                    );
                } else {
                    tokens.push_back(
                        makeToken(
                            TokenType::Equal,
                            "=",
                            tokenLine,
                            tokenColumn
                        )
                    );
                }

                break;

            case '!':
                advance();

                if (current() != '=') {
                    throw std::runtime_error(
                        "Expected '=' after '!'"
                    );
                }

                advance();

                tokens.push_back(
                    makeToken(
                        TokenType::NotEqual,
                        "!=",
                        tokenLine,
                        tokenColumn
                    )
                );

                break;

            case '<':
                advance();

                if (current() == '=') {
                    advance();

                    tokens.push_back(
                        makeToken(
                            TokenType::LessEqual,
                            "<=",
                            tokenLine,
                            tokenColumn
                        )
                    );
                } else {
                    tokens.push_back(
                        makeToken(
                            TokenType::Less,
                            "<",
                            tokenLine,
                            tokenColumn
                        )
                    );
                }

                break;

            case '>':
                advance();

                if (current() == '=') {
                    advance();

                    tokens.push_back(
                        makeToken(
                            TokenType::GreaterEqual,
                            ">=",
                            tokenLine,
                            tokenColumn
                        )
                    );
                } else {
                    tokens.push_back(
                        makeToken(
                            TokenType::Greater,
                            ">",
                            tokenLine,
                            tokenColumn
                        )
                    );
                }

                break;

            default:
                throw std::runtime_error(
                    std::string("Unexpected character: ") + c
                );
        }
    }

    tokens.push_back(
        Token(
            TokenType::EndOfFile,
            "",
            line,
            column
        )
    );

    return tokens;
}

}