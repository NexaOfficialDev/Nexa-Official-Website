#include "nexa/codegen.hpp"

#include <sstream>
#include <stdexcept>

namespace nexa {

CodeGenerator::CodeGenerator()
    : indent(0),
      loopDepth(0),
      functionDepth(0) {
}

void CodeGenerator::emit(
    const std::string& text
) {
    output += text;
}

void CodeGenerator::emitLine(
    const std::string& text
) {
    for (int i = 0; i < indent; ++i) {
        output += "    ";
    }

    output += text;
    output += "\n";
}

std::string CodeGenerator::escapeString(
    const std::string& value
) {
    std::string result;

    for (size_t i = 0; i < value.size(); ++i) {
        char c = value[i];

        switch (c) {
            case '\\':
                result += "\\\\";
                break;

            case '"':
                result += "\\\"";
                break;

            case '\n':
                result += "\\n";
                break;

            case '\t':
                result += "\\t";
                break;

            default:
                result += c;
                break;
        }
    }

    return result;
}

std::string CodeGenerator::functionName(
    const std::string& name
) {
    return "nx_" + name;
}

std::string CodeGenerator::generate(
    const Program& program
) {
    output.clear();
    indent = 0;
    loopDepth = 0;
    functionDepth = 0;

    generateProgram(program);

    return output;
}

void CodeGenerator::generateProgram(
    const Program& program
) {
    emitLine("#include <vector>");
    emitLine("#include <string>");
    emitLine("#include <stdexcept>");
    emitLine("#include <iostream>");
    emitLine("#include \"nexa/runtime.hpp\"");
    emitLine("");

    for (size_t i = 0;
         i < program.statements.size();
         ++i) {

        FunctionStatement* function =
            dynamic_cast<FunctionStatement*>(
                program.statements[i].get()
            );

        if (function) {
            emitLine(
                "static nexa::Value " +
                functionName(function->name) +
                "(const std::vector<nexa::Value>& args, nexa::Environment& parentEnv);"
            );
        }
    }

    emitLine("");

    for (size_t i = 0;
         i < program.statements.size();
         ++i) {

        FunctionStatement* function =
            dynamic_cast<FunctionStatement*>(
                program.statements[i].get()
            );

        if (function) {
            generateFunction(*function);
            emitLine("");
        }
    }

    emitLine("int main() {");
    indent++;

    emitLine("try {");
    indent++;
    emitLine("nexa::Environment env;");

    for (size_t i = 0;
         i < program.statements.size();
         ++i) {

        if (dynamic_cast<FunctionStatement*>(
                program.statements[i].get())) {
            continue;
        }

        generateStatement(
            program.statements[i]
        );
    }

    emitLine("return 0;");
    indent--;
    emitLine("}");
    emitLine("catch (const std::exception& e) {");
    indent++;
    emitLine("std::cerr << \"Runtime error: \" << e.what() << std::endl;");
    emitLine("return 1;");
    indent--;
    emitLine("}");

    indent--;
    emitLine("}");
}

void CodeGenerator::generateFunction(
    const FunctionStatement& function
) {
    emitLine(
        "static nexa::Value " +
        functionName(function.name) +
        "(const std::vector<nexa::Value>& args, nexa::Environment& parentEnv) {"
    );

    indent++;

    emitLine("nexa::Environment env(parentEnv);");
    emitLine(
        "if (args.size() != " +
        std::to_string(function.parameters.size()) +
        ") throw std::runtime_error(\"Function " +
        escapeString(function.name) +
        " expects " +
        std::to_string(function.parameters.size()) +
        " argument(s).\");"
    );

    for (size_t i = 0;
         i < function.parameters.size();
         ++i) {

        emitLine(
            "if (args.size() > " +
            std::to_string(i) +
            ") env.set(\"" +
            escapeString(function.parameters[i]) +
            "\", args[" +
            std::to_string(i) +
            "]);"
        );
    }

    functionDepth++;
    generateStatements(function.body);
    functionDepth--;

    emitLine("return nexa::Value::null();");

    indent--;

    emitLine("}");
}

void CodeGenerator::generateStatements(
    const std::vector<StmtPtr>& statements
) {
    for (size_t i = 0; i < statements.size(); ++i) {
        generateStatement(statements[i]);
    }
}

void CodeGenerator::generateStatement(
    const StmtPtr& statement
) {
    if (LetStatement* let =
            dynamic_cast<LetStatement*>(
                statement.get())) {

        emitLine(
            "env.set(\"" +
            escapeString(let->name) +
            "\", " +
            generateExpression(let->value) +
            ");"
        );

        return;
    }

    if (AssignmentStatement* assignment =
            dynamic_cast<AssignmentStatement*>(
                statement.get())) {

        emitLine(
            "env.assign(\"" +
            escapeString(assignment->name) +
            "\", " +
            generateExpression(assignment->value) +
            ");"
        );

        return;
    }

    if (ExpressionStatement* expression =
            dynamic_cast<ExpressionStatement*>(
                statement.get())) {

        emitLine(
            generateExpression(
                expression->expression
            ) + ";"
        );

        return;
    }

    if (IfStatement* ifStatement =
            dynamic_cast<IfStatement*>(
                statement.get())) {

        emitLine(
            "if (nexa::truthy(" +
            generateExpression(
                ifStatement->condition
            ) +
            ")) {"
        );

        indent++;

        generateStatements(
            ifStatement->thenBranch
        );

        indent--;

        emitLine("}");

        if (!ifStatement->elseBranch.empty()) {
            emitLine("else {");

            indent++;

            generateStatements(
                ifStatement->elseBranch
            );

            indent--;

            emitLine("}");
        }

        return;
    }

    if (WhileStatement* whileStatement =
            dynamic_cast<WhileStatement*>(
                statement.get())) {

        emitLine(
            "while (nexa::truthy(" +
            generateExpression(
                whileStatement->condition
            ) +
            ")) {"
        );

        indent++;
        loopDepth++;

        generateStatements(
            whileStatement->body
        );

        loopDepth--;
        indent--;

        emitLine("}");

        return;
    }

    if (RepeatStatement* repeatStatement =
            dynamic_cast<RepeatStatement*>(
                statement.get())) {

        emitLine(
            "for (long long nx_i = 0; nx_i < nexa::repeatCount(" +
            generateExpression(
                repeatStatement->count
            ) +
            "); ++nx_i) {"
        );

        indent++;
        loopDepth++;

        generateStatements(
            repeatStatement->body
        );

        loopDepth--;
        indent--;

        emitLine("}");

        return;
    }

    if (dynamic_cast<BreakStatement*>(
            statement.get())) {

        if (loopDepth == 0) {
            throw std::runtime_error(
                "'break' can only be used inside a loop."
            );
        }

        emitLine("break;");
        return;
    }

    if (dynamic_cast<ContinueStatement*>(
            statement.get())) {

        if (loopDepth == 0) {
            throw std::runtime_error(
                "'continue' can only be used inside a loop."
            );
        }

        emitLine("continue;");
        return;
    }

    if (ReturnStatement* returnStatement =
            dynamic_cast<ReturnStatement*>(
                statement.get())) {

        if (functionDepth == 0) {
            throw std::runtime_error(
                "'return' can only be used inside a function."
            );
        }

        if (returnStatement->value) {
            emitLine(
                "return " +
                generateExpression(
                    returnStatement->value
                ) +
                ";"
            );
        } else {
            emitLine(
                "return nexa::Value::null();"
            );
        }

        return;
    }

    if (dynamic_cast<FunctionStatement*>(
            statement.get())) {
        return;
    }

    throw std::runtime_error(
        "Unknown statement during code generation."
    );
}

std::string CodeGenerator::generateExpression(
    const ExprPtr& expression
) {
    if (LiteralExpression* literal =
            dynamic_cast<LiteralExpression*>(
                expression.get())) {

        switch (literal->kind) {
            case LiteralExpression::Kind::Number:
                return "nexa::Value::number(" +
                    std::to_string(
                        literal->numberValue
                    ) +
                    ")";

            case LiteralExpression::Kind::String:
                return "nexa::Value::string(\"" +
                    escapeString(
                        literal->stringValue
                    ) +
                    "\")";

            case LiteralExpression::Kind::Boolean:
                return std::string(
                    "nexa::Value::boolean("
                ) +
                (literal->booleanValue
                    ? "true"
                    : "false") +
                ")";

            case LiteralExpression::Kind::Null:
                return "nexa::Value::null()";
        }
    }

    if (IdentifierExpression* identifier =
            dynamic_cast<IdentifierExpression*>(
                expression.get())) {

        return "env.get(\"" +
            escapeString(identifier->name) +
            "\")";
    }

    if (ListExpression* list =
            dynamic_cast<ListExpression*>(
                expression.get())) {

        std::string result =
            "nexa::Value::list({";

        for (size_t i = 0;
             i < list->elements.size();
             ++i) {

            if (i != 0) {
                result += ", ";
            }

            result += generateExpression(
                list->elements[i]
            );
        }

        result += "})";

        return result;
    }

    if (UnaryExpression* unary =
            dynamic_cast<UnaryExpression*>(
                expression.get())) {

        std::string operand =
            generateExpression(
                unary->operand
            );

        if (unary->op == "-") {
            return "nexa::Value::number(-(" +
                operand +
                ").toNumber())";
        }

        if (unary->op == "not") {
            return "nexa::Value::boolean(!nexa::truthy(" +
                operand +
                "))";
        }
    }

    if (BinaryExpression* binary =
            dynamic_cast<BinaryExpression*>(
                expression.get())) {

        std::string left =
            generateExpression(binary->left);

        std::string right =
            generateExpression(binary->right);

        if (binary->op == "and") {
            return "nexa::Value::boolean(nexa::truthy(" +
                left +
                ") ? nexa::truthy(" +
                right +
                ") : false)";
        }

        if (binary->op == "or") {
            return "nexa::Value::boolean(nexa::truthy(" +
                left +
                ") ? true : nexa::truthy(" +
                right +
                "))";
        }

        return "((" + left + ") " +
            binary->op +
            " (" + right + "))";
    }

    if (FunctionCallExpression* call =
            dynamic_cast<FunctionCallExpression*>(
                expression.get())) {

        if (call->name == "print") {
            if (call->arguments.size() != 1) {
                throw std::runtime_error(
                    "print() expects one argument."
                );
            }

            return "(nexa::print(" +
                generateExpression(
                    call->arguments[0]
                ) +
                "), nexa::Value::null())";
        }

        if (call->name == "length") {
            if (call->arguments.size() != 1) {
                throw std::runtime_error(
                    "length() expects one argument."
                );
            }

            return "nexa::length(" +
                generateExpression(
                    call->arguments[0]
                ) +
                ")";
        }

        if (call->name == "type") {
            if (call->arguments.size() != 1) {
                throw std::runtime_error(
                    "type() expects one argument."
                );
            }

            return "nexa::typeOf(" +
                generateExpression(
                    call->arguments[0]
                ) +
                ")";
        }

        std::string result =
            functionName(call->name) +
            "({";

        for (size_t i = 0;
             i < call->arguments.size();
             ++i) {

            if (i != 0) {
                result += ", ";
            }

            result += generateExpression(
                call->arguments[i]
            );
        }

        result += "}, env)";

        return result;
    }

    if (IndexExpression* index =
            dynamic_cast<IndexExpression*>(
                expression.get())) {

        return "(" +
            generateExpression(index->object) +
            ").index(static_cast<size_t>(" +
            generateExpression(index->index) +
            ".toNumber()))";
    }

    throw std::runtime_error(
        "Unknown expression during code generation."
    );
}

}