#include "nexa/ast.hpp"

namespace nexa {

LiteralExpression::LiteralExpression()
    : kind(Kind::Null),
      numberValue(0.0),
      booleanValue(false) {
}

IdentifierExpression::IdentifierExpression(
    const std::string& name
)
    : name(name) {
}

UnaryExpression::UnaryExpression(
    const std::string& op,
    ExprPtr operand
)
    : op(op),
      operand(operand) {
}

BinaryExpression::BinaryExpression(
    const std::string& op,
    ExprPtr left,
    ExprPtr right
)
    : op(op),
      left(left),
      right(right) {
}

FunctionCallExpression::FunctionCallExpression(
    const std::string& name
)
    : name(name) {
}

IndexExpression::IndexExpression(
    ExprPtr object,
    ExprPtr index
)
    : object(object),
      index(index) {
}

ExpressionStatement::ExpressionStatement(
    ExprPtr expression
)
    : expression(expression) {
}

LetStatement::LetStatement(
    const std::string& name,
    ExprPtr value
)
    : name(name),
      value(value) {
}

AssignmentStatement::AssignmentStatement(
    const std::string& name,
    ExprPtr value
)
    : name(name),
      value(value) {
}

}