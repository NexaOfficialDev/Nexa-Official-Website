#include <fstream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
#include <cctype>

namespace nexa {
namespace web {

static std::string trim(const std::string& s) {
    size_t a = 0;
    while (a < s.size() && std::isspace(static_cast<unsigned char>(s[a]))) ++a;
    size_t b = s.size();
    while (b > a && std::isspace(static_cast<unsigned char>(s[b - 1]))) --b;
    return s.substr(a, b - a);
}

static std::string quoted(const std::string& line, size_t& pos) {
    while (pos < line.size() && std::isspace(static_cast<unsigned char>(line[pos]))) ++pos;
    if (pos >= line.size() || line[pos] != '"') throw std::runtime_error("Expected a quoted string.");
    ++pos;
    std::string out;
    while (pos < line.size()) {
        char c = line[pos++];
        if (c == '"') return out;
        if (c == '\\' && pos < line.size()) {
            char n = line[pos++];
            if (n == 'n') out += '\n';
            else if (n == 't') out += '\t';
            else out += n;
        } else out += c;
    }
    throw std::runtime_error("Unterminated quoted string.");
}

static std::string escapeHtml(const std::string& s) {
    std::string out;
    for (size_t i = 0; i < s.size(); ++i) {
        switch (s[i]) {
            case '&': out += "&amp;"; break;
            case '<': out += "&lt;"; break;
            case '>': out += "&gt;"; break;
            case '"': out += "&quot;"; break;
            default: out += s[i]; break;
        }
    }
    return out;
}

static std::string attr(const std::string& s) {
    return escapeHtml(s);
}

bool compileFile(const std::string& filename, std::string& output, std::string& error) {
    std::ifstream file(filename.c_str(), std::ios::in | std::ios::binary);
    if (!file) { error = "Could not open NexaW file: " + filename; return false; }

    std::ostringstream ss;
    ss << file.rdbuf();

    std::string title = "Nexa Web";
    std::string lang = "en";
    std::string style;
    std::vector<std::string> body;
    bool started = false;

    std::istringstream input(ss.str());
    std::string line;
    int lineNo = 0;

    while (std::getline(input, line)) {
        ++lineNo;
        line = trim(line);
        if (line.empty() || line[0] == '#') continue;

        size_t p = 0;
        std::string command;
        while (p < line.size() && !std::isspace(static_cast<unsigned char>(line[p]))) command += line[p++];

        try {
            if (command == "page") {
                title = quoted(line, p);
                started = true;
            } else if (command == "lang") {
                lang = attr(quoted(line, p));
            } else if (command == "style") {
                style += quoted(line, p);
                style += "\n";
            } else if (command == "h1" || command == "h2" || command == "h3" || command == "p" || command == "small") {
                std::string text = escapeHtml(quoted(line, p));
                body.push_back("<" + command + ">" + text + "</" + command + ">");
            } else if (command == "link") {
                std::string label = escapeHtml(quoted(line, p));
                std::string href = attr(quoted(line, p));
                body.push_back("<a href=\"" + href + "\">" + label + "</a>");
            } else if (command == "raw") {
                body.push_back(quoted(line, p));
            } else if (command == "end") {
                break;
            } else {
                throw std::runtime_error("Unknown NexaW command: " + command);
            }
        } catch (const std::exception& e) {
            std::ostringstream msg;
            msg << "NXW" << (100 + lineNo) << ": " << e.what();
            error = msg.str();
            return false;
        }
    }

    if (!started) {
        error = "NXW101: NexaW file must start with page \"Title\".";
        return false;
    }

    std::ostringstream html;
    html << "<!doctype html>\n<html lang=\"" << lang << "\">\n<head>\n"
         << "<meta charset=\"utf-8\">\n<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">\n"
         << "<title>" << escapeHtml(title) << "</title>\n";
    if (!style.empty()) html << "<style>\n" << style << "</style>\n";
    html << "</head>\n<body>\n";
    for (size_t i = 0; i < body.size(); ++i) html << body[i] << "\n";
    html << "</body>\n</html>\n";

    output = html.str();
    return true;
}

} // namespace web
} // namespace nexa
