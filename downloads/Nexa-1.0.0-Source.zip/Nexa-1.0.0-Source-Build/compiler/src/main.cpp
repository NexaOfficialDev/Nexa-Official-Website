#include <fstream>
#include <iostream>
#include <string>
#ifdef _WIN32
#include <windows.h>
#include <shellapi.h>
#endif
#ifdef _WIN32
#include <direct.h>
#else
#include <sys/stat.h>
#endif

#include "nexa/compiler.hpp"
#include "nexa/web.hpp"
#include "nexa/app.hpp"

static const char* NEXA_VERSION = "1.0.0";


#ifdef _WIN32
static int runNexaWeb(const std::string& source) {
    std::string output, error;
    if (!nexa::web::compileFile(source, output, error)) { std::cerr << error << std::endl; return 1; }
    char tempPath[MAX_PATH], tempFile[MAX_PATH];
    GetTempPathA(MAX_PATH, tempPath);
    GetTempFileNameA(tempPath, "nxw", 0, tempFile);
    std::string html = std::string(tempFile) + ".html";
    std::ofstream f(html.c_str(), std::ios::binary); if(!f){std::cerr<<"NXW004: Could not create temporary page."<<std::endl;return 1;} f<<output; f.close();
    HKEY hk; bool chosen=false;
    if(RegOpenKeyExA(HKEY_CURRENT_USER,"Software\\Nexa\\NXW",0,KEY_READ,&hk)==ERROR_SUCCESS){ DWORD v=0,n=sizeof(v); RegQueryValueExA(hk,"BrowserChosen",0,0,(LPBYTE)&v,&n); chosen=(v==1); RegCloseKey(hk); }
    if(!chosen){
        std::string cmd="rundll32.exe shell32.dll,OpenAs_RunDLL \""+html+"\"";
        system(cmd.c_str());
        Sleep(1200);
        RegCreateKeyExA(HKEY_CURRENT_USER,"Software\\Nexa\\NXW",0,0,0,KEY_WRITE,0,&hk,0);
        DWORD one=1; RegSetValueExA(hk,"BrowserChosen",0,REG_DWORD,(BYTE*)&one,sizeof(one)); RegCloseKey(hk);
    } else {
        ShellExecuteA(0,"open",html.c_str(),0,0,SW_SHOWNORMAL);
    }
    return 0;
}

static int installAssociations(bool remove) {
    char exe[MAX_PATH]; GetModuleFileNameA(0, exe, MAX_PATH);
    std::string exeDir(exe);
    size_t slash = exeDir.find_last_of("\\/");
    if (slash != std::string::npos) exeDir.erase(slash + 1);
    std::string icon = std::string("\"") + exeDir + "nexa-file.ico\",0";
    if (remove) {
        RegDeleteKeyA(HKEY_CURRENT_USER, "Software\\Classes\\Nexa.NX");
        RegDeleteKeyA(HKEY_CURRENT_USER, "Software\\Classes\\Nexa.NXW");
        RegDeleteKeyA(HKEY_CURRENT_USER, "Software\\Classes\\.nx");
        RegDeleteKeyA(HKEY_CURRENT_USER, "Software\\Classes\\.nxw");
        return 0;
    }
    auto set=[&](const char* key,const char* value,const char* data){HKEY h; if(RegCreateKeyExA(HKEY_CURRENT_USER,key,0,0,0,KEY_WRITE,0,&h,0)!=ERROR_SUCCESS)return; RegSetValueExA(h,value,0,REG_SZ,(BYTE*)data,(DWORD)strlen(data)+1);RegCloseKey(h);};
    set("Software\\Classes\\Nexa.NX", "", "Nexa Source File");
    set("Software\\Classes\\Nexa.NX\\DefaultIcon", "", icon.c_str());
    set("Software\\Classes\\Nexa.NX\\shell\\open\\command", "", "notepad.exe \"%1\"");
    set("Software\\Classes\\.nx", "", "Nexa.NX");
    set("Software\\Classes\\Nexa.NXW", "", "NexaW Website Source");
    set("Software\\Classes\\Nexa.NXW\\DefaultIcon", "", icon.c_str());
    set("Software\\Classes\\Nexa.NXW\\shell\\open\\command", "", (std::string("\"") + exe + "\" web open \"%1\"").c_str());
    set("Software\\Classes\\.nxw", "", "Nexa.NXW");
    RegCreateKeyExA(HKEY_CURRENT_USER,"Software\\Nexa\\NXW",0,0,0,KEY_WRITE,0,0,0);
    std::cout<<"Nexa file associations installed (.nx, .nxw). .nxa associations are left untouched."<<std::endl;
    return 0;
}
#endif

void printHelp() {
    std::cout
        << "Nexa "
        << NEXA_VERSION
        << std::endl
        << std::endl
        << "Usage:" << std::endl
        << "  nexa version" << std::endl
        << "  nexa help" << std::endl
        << "  nexa check <file.nx>" << std::endl
        << "  nexa build <file.nx>" << std::endl
        << "  nexa web <file.nxw> [output.html]" << std::endl
        << "  nexa web new [folder]" << std::endl
        << "  nexa app new [folder]" << std::endl
        << "  nexa app build <file.nxa> [output.cpp]" << std::endl
        << "  nexa app run <file.nxa>" << std::endl
        << "  nexa install" << std::endl
        << "  nexa uninstall" << std::endl;
}

int main(
    int argc,
    char* argv[]
) {
    if (argc < 2) {
        printHelp();
        return 0;
    }

    std::string command = argv[1];

#ifdef _WIN32
    if (command == "install") return installAssociations(false);
    if (command == "uninstall") return installAssociations(true);
#endif

    if (command == "version") {
        std::cout
            << "Nexa "
            << NEXA_VERSION
            << std::endl;

        return 0;
    }

    if (command == "help") {
        printHelp();
        return 0;
    }

    if (command == "app") {
#ifdef _WIN32
        if (argc >= 3 && std::string(argv[2]) == "run") {
            if (argc < 4) { std::cerr << "NXA004: Missing .nxa source file." << std::endl; return 1; }
            std::string generated, error;
            if (!nexa::app::compileFile(argv[3], generated, error)) { std::cerr << error << std::endl; return 1; }
            char tempPath[MAX_PATH], cppFile[MAX_PATH], exeFile[MAX_PATH]; GetTempPathA(MAX_PATH,tempPath); GetTempFileNameA(tempPath,"nxa",0,cppFile); DeleteFileA(cppFile);
            std::string cppPath=std::string(cppFile)+".cpp", exePath=std::string(cppFile)+".exe"; std::ofstream out(cppPath.c_str(),std::ios::binary); if(!out){std::cerr<<"NXA005: Could not create temporary build file."<<std::endl;return 1;} out<<generated; out.close();
            std::string cmd="g++ -std=c++11 \""+cppPath+"\" -o \""+exePath+"\" -mwindows"; int rc=system(cmd.c_str()); if(rc!=0){std::cerr<<"NXA006: Native build failed. Ensure MinGW is installed and g++ is in PATH."<<std::endl;return 1;}
            ShellExecuteA(0,"open",exePath.c_str(),0,0,SW_SHOWNORMAL); return 0;
        }
#endif
        if (argc >= 3 && std::string(argv[2]) == "new") {
            std::string directory = argc >= 4 ? argv[3] : ".";
            std::string title;
            std::cout << "Nexa App wizard" << std::endl;
            std::cout << "App title: ";
            std::getline(std::cin, title);
            if (title.empty()) title = "My Nexa App";
            std::string path = directory;
            if (directory != "." && !directory.empty()) {
#ifdef _WIN32
                _mkdir(directory.c_str());
#else
                mkdir(directory.c_str(), 0755);
#endif
            }
            if (!path.empty() && path[path.size()-1] != '\\' && path[path.size()-1] != '/') path += "/";
            path += "main.nxa";
            std::ofstream out(path.c_str(), std::ios::binary);
            if (!out) { std::cerr << "NXA003: Could not create " << path << std::endl; return 1; }
            out << "# Nexa App generated by Nexa " << NEXA_VERSION << "\n"
                << "app \"" << title << "\"\n"
                << "type \"gui\"\n"
                << "window \"" << title << "\" 800 500\n"
                << "text \"status\" 30 30 500 40\n"
                << "input \"name\" \"Type your name\" 30 90 300 35\n"
                << "button \"hello\" 30 140 140 40\n"
                << "on \"click\" \"hello\" \"message\" \"Hello from Nexa!\"\n"
                << "end\n";
            std::cout << "Created: " << path << std::endl;
            std::cout << "Build it with: nexa app build " << path << std::endl;
            return 0;
        }
        if (argc < 3 || (std::string(argv[2]) != "build" && std::string(argv[2]) != "new")) { std::cerr << "NXA001: Use 'nexa app new [folder]' or 'nexa app build <file.nxa> [output.cpp]'." << std::endl; return 1; }
        if (std::string(argv[2]) == "new") { return 1; }
        if (argc < 4) { std::cerr << "NXA001: Missing .nxa source file." << std::endl; return 1; }
        std::string generated, error;
        if (!nexa::app::compileFile(argv[3], generated, error)) { std::cerr << error << std::endl; return 1; }
        std::string outputFile = argc >= 5 ? argv[4] : argv[3];
        if (argc < 5) { size_t dot=outputFile.find_last_of('.'); if(dot!=std::string::npos) outputFile=outputFile.substr(0,dot); outputFile += ".generated.cpp"; }
        std::ofstream file(outputFile.c_str(), std::ios::binary);
        if(!file){std::cerr<<"NXA002: Could not write output file."<<std::endl;return 1;}
        file<<generated; std::cout<<"Generated: "<<outputFile<<std::endl; return 0;
    }

    if (command == "web") {
#ifdef _WIN32
        if (argc >= 3 && std::string(argv[2]) == "open") { if(argc<4){std::cerr<<"NXW004: Missing .nxw source file."<<std::endl;return 1;} return runNexaWeb(argv[3]); }
#endif
        if (argc >= 3 && std::string(argv[2]) == "new") {
            std::string directory = argc >= 4 ? argv[3] : ".";
            std::string title;
            std::cout << "NexaW website wizard" << std::endl;
            std::cout << "Site title: ";
            std::getline(std::cin, title);
            if (title.empty()) title = "My Nexa Website";

            std::string path = directory;
            if (!path.empty() && path[path.size() - 1] != '\\' && path[path.size() - 1] != '/') path += "/";
            path += "index.nxw";

            std::ofstream wizard(path.c_str(), std::ios::out | std::ios::binary);
            if (!wizard) {
                std::cerr << "NXW003: Could not create " << path << std::endl;
                return 1;
            }
            wizard << "# NexaW website generated by Nexa " << NEXA_VERSION << "\n"
                   << "page \"" << title << "\"\n"
                   << "lang \"en\"\n"
                   << "style \"body{font-family:system-ui,Segoe UI,Arial;margin:0;padding:60px;background:#090b10;color:#e8ecf4}main{max-width:900px;margin:auto}a{color:#7dd3fc}\"\n"
                   << "raw \"<main>\"\n"
                   << "h1 \"" << title << "\"\n"
                   << "p \"Welcome to your new NexaW website.\"\n"
                   << "raw \"</main>\"\n"
                   << "end\n";
            std::cout << "Created: " << path << std::endl;
            std::cout << "Build it with: nexa web " << path << std::endl;
            return 0;
        }

        if (argc < 3) {
            std::cerr << "NXW001: Missing .nxw source file or 'new'." << std::endl;
            return 1;
        }

        std::string output;
        std::string error;
        if (!nexa::web::compileFile(argv[2], output, error)) {
            std::cerr << error << std::endl;
            return 1;
        }

        std::string outputFile;
        if (argc >= 4) {
            outputFile = argv[3];
        } else {
            outputFile = argv[2];
            size_t dot = outputFile.find_last_of('.');
            if (dot != std::string::npos) outputFile = outputFile.substr(0, dot);
            outputFile += ".html";
        }

        std::ofstream file(outputFile.c_str(), std::ios::out | std::ios::binary);
        if (!file) {
            std::cerr << "NXW002: Could not write output file." << std::endl;
            return 1;
        }
        file << output;
        std::cout << "Generated: " << outputFile << std::endl;
        return 0;
    }

    if (argc < 3) {
        std::cerr
            << "NX100: Missing source file."
            << std::endl;

        return 1;
    }

    std::string filename = argv[2];

    nexa::Compiler compiler;

    std::string generated;

    if (!compiler.compileFile(
            filename,
            generated)) {

        compiler.getDiagnostics().print();

        return 1;
    }

    if (command == "check") {
        std::cout
            << "Nexa "
            << NEXA_VERSION
            << ": syntax OK"
            << std::endl;

        return 0;
    }

    if (command == "build") {
        std::string outputFile = filename;

        size_t slash =
            outputFile.find_last_of(
                "\\/"
            );

        size_t dot =
            outputFile.find_last_of('.');

        if (dot == std::string::npos ||
            (slash != std::string::npos &&
             dot < slash)) {
            dot = outputFile.size();
        }

        outputFile =
            outputFile.substr(0, dot) +
            ".generated.cpp";

        std::ofstream file(
            outputFile.c_str(),
            std::ios::out | std::ios::binary
        );

        if (!file) {
            std::cerr
                << "NX501: Could not write generated file."
                << std::endl;

            return 1;
        }

        file << generated;

        std::cout
            << "Generated: "
            << outputFile
            << std::endl;

        return 0;
    }

    std::cerr
        << "NX101: Unknown command: "
        << command
        << std::endl;

    printHelp();

    return 1;
}
