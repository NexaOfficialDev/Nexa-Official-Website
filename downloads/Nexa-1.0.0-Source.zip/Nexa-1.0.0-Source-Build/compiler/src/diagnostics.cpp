#include "nexa/diagnostics.hpp"

#include <iostream>

namespace nexa {

Diagnostic::Diagnostic(
    DiagnosticSeverity severity,
    const std::string& code,
    const std::string& message,
    int line,
    int column
)
    : severity(severity),
      code(code),
      message(message),
      line(line),
      column(column) {
}

void Diagnostics::info(
    const std::string& code,
    const std::string& message,
    int line,
    int column
) {
    diagnostics.push_back(
        Diagnostic(
            DiagnosticSeverity::Info,
            code,
            message,
            line,
            column
        )
    );
}

void Diagnostics::warning(
    const std::string& code,
    const std::string& message,
    int line,
    int column
) {
    diagnostics.push_back(
        Diagnostic(
            DiagnosticSeverity::Warning,
            code,
            message,
            line,
            column
        )
    );
}

void Diagnostics::error(
    const std::string& code,
    const std::string& message,
    int line,
    int column
) {
    diagnostics.push_back(
        Diagnostic(
            DiagnosticSeverity::Error,
            code,
            message,
            line,
            column
        )
    );
}

bool Diagnostics::hasErrors() const {
    for (size_t i = 0;
         i < diagnostics.size();
         ++i) {

        if (diagnostics[i].severity ==
            DiagnosticSeverity::Error) {
            return true;
        }
    }

    return false;
}

size_t Diagnostics::count() const {
    return diagnostics.size();
}

void Diagnostics::clear() {
    diagnostics.clear();
}

void Diagnostics::print() const {
    for (size_t i = 0;
         i < diagnostics.size();
         ++i) {

        const Diagnostic& d =
            diagnostics[i];

        std::cout
            << severityName(d.severity)
            << " "
            << d.code;

        if (d.line > 0) {
            std::cout
                << " ["
                << d.line
                << ":"
                << d.column
                << "]";
        }

        std::cout
            << ": "
            << d.message
            << std::endl;
    }
}

const char* severityName(
    DiagnosticSeverity severity
) {
    switch (severity) {
        case DiagnosticSeverity::Info:
            return "info";

        case DiagnosticSeverity::Warning:
            return "warning";

        case DiagnosticSeverity::Error:
            return "error";
    }

    return "unknown";
}

}