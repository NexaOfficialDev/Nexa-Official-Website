@echo off
setlocal EnableExtensions
title Nexa 1.0.0 Installer Builder
set "ROOT=%~dp0"
set "DIST=%ROOT%dist"
set "ISCC=C:\Users\robinson\AppData\Local\Programs\Inno Setup 6\ISCC.exe"
set "WIXBIN=C:\Program Files (x86)\WiX Toolset v3.11\bin"
set "X86GCC=C:\mingw32\bin\gcc.exe"
set "X64GCC=C:\mingw64\bin\gcc.exe"
if not exist "%DIST%" mkdir "%DIST%"

echo === Nexa 1.0.0 Installer Builder ===
if not exist "%X86GCC%" (echo ERROR: Missing "%X86GCC%"& goto fail)
if not exist "%ISCC%" (echo ERROR: Missing "%ISCC%"& goto fail)
if not exist "%WIXBIN%\candle.exe" (echo ERROR: Missing WiX candle.exe& goto fail)
if not exist "%WIXBIN%\light.exe" (echo ERROR: Missing WiX light.exe& goto fail)

echo Building Nexa x86...
call "%ROOT%build-windows.bat" x86
if errorlevel 1 goto fail
if not exist "%ROOT%release-x86\nexa.exe" (echo ERROR: release-x86\nexa.exe not found& goto fail)

echo Building x86 EXE installer...
"%ISCC%" "%ROOT%installer\Nexa32.iss"
if errorlevel 1 goto fail
echo Building x86 MSI installer...
"%WIXBIN%\candle.exe" "%ROOT%installer\Nexa32.wxs" -o "%ROOT%installer\Nexa32.wixobj"
if errorlevel 1 goto fail
"%WIXBIN%\light.exe" "%ROOT%installer\Nexa32.wixobj" -o "%DIST%\Nexa-1.0.0-x86.msi"
if errorlevel 1 goto fail

if not exist "%X64GCC%" (
 echo NOTE: No x64 compiler at C:\mingw64\bin\gcc.exe. Skipping x64 installers.
 goto done
)
echo Building Nexa x64...
call "%ROOT%build-windows.bat" x64
if errorlevel 1 goto fail
if not exist "%ROOT%release-x64\nexa.exe" (echo ERROR: release-x64\nexa.exe not found& goto fail)
"%ISCC%" "%ROOT%installer\Nexa64.iss"
if errorlevel 1 goto fail
"%WIXBIN%\candle.exe" "%ROOT%installer\Nexa64.wxs" -o "%ROOT%installer\Nexa64.wixobj"
if errorlevel 1 goto fail
"%WIXBIN%\light.exe" "%ROOT%installer\Nexa64.wixobj" -o "%DIST%\Nexa-1.0.0-x64.msi"
if errorlevel 1 goto fail
goto done

:fail
echo.
echo BUILD FAILED. Send the complete output above.
pause
exit /b 1
:done
echo.
echo Installer output folder:
echo "%DIST%"
dir "%DIST%"
pause
exit /b 0
