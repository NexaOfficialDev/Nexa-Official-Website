#define OutputName "Nexa-1.0.0-win32-setup"
#define Binary "..\release-x86\nexa.exe"
#define AppName "Nexa"
#define AppVersion "1.0.0"
[Setup]
OutputDir=..\dist
AppId={{B4A7F0B5-5D50-4A2B-9F42-0E0960000001}}
AppName={#AppName}
AppVersion={#AppVersion}
DefaultDirName=C:\Nexa\nex32
DefaultGroupName=Nexa
DisableProgramGroupPage=yes
OutputBaseFilename=Nexa-1.0.0-x86-Setup
Compression=lzma
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
[Files]
Source: "{#Binary}"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\README.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\LICENSE.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\assets\nexa-file.ico"; DestDir: "{app}"; Flags: ignoreversion
[Icons]
Name: "{group}\Nexa Command Prompt"; Filename: "cmd.exe"; Parameters: "/K cd /d ""{app}"""
Name: "{group}\Uninstall Nexa"; Filename: "{uninstallexe}"
[Environment]
Name: "NEXA_HOME"; Value: "{app}"; Type: user
Name: "PATH"; Value: "{app}"; Type: user; Check: NeedsAddToPath
[Code]
function NeedsAddToPath(): Boolean;
begin
  Result := Pos(';' + ExpandConstant('{app}') + ';', ';' + GetEnv('PATH') + ';') = 0;
end;

[Registry]
Root: HKLM; Subkey: "Software\Classes\Nexa.NX"; ValueType: string; ValueName: ""; ValueData: "Nexa Source File"; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\Nexa.NX\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\nexa-file.ico,0"
Root: HKLM; Subkey: "Software\Classes\Nexa.NX\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """notepad.exe"" ""%1"""
Root: HKLM; Subkey: "Software\Classes\.nx"; ValueType: string; ValueName: ""; ValueData: "Nexa.NX"
Root: HKLM; Subkey: "Software\Classes\Nexa.NXW"; ValueType: string; ValueName: ""; ValueData: "NexaW Website Source"; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\Nexa.NXW\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\nexa-file.ico,0"
Root: HKLM; Subkey: "Software\Classes\Nexa.NXW\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\nexa.exe"" web open ""%1"""
Root: HKLM; Subkey: "Software\Classes\.nxw"; ValueType: string; ValueName: ""; ValueData: "Nexa.NXW"
