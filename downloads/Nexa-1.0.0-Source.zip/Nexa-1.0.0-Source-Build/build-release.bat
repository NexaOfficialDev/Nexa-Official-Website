@echo off
setlocal
set PATH=C:\mingw32\bin;%PATH%
if not exist build mkdir build
cd build
g++ -std=c++11 -I..\compiler\include -I..\runtime\include ..\compiler\src\main.cpp ..\compiler\src\compiler.cpp ..\compiler\src\token.cpp ..\compiler\src\diagnostics.cpp ..\compiler\src\codegen.cpp ..\compiler\src\ast.cpp ..\compiler\src\parser.cpp ..\compiler\src\lexer.cpp ..\compiler\src\web.cpp ..\compiler\src\app.cpp ..\runtime\src\runtime.cpp -o nexa.exe
if errorlevel 1 exit /b 1
nexa.exe version
cd ..
