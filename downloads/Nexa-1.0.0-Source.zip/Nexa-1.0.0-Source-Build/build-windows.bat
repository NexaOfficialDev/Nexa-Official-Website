@echo off
setlocal
set ROOT=%~dp0
if /I "%1"=="x64" goto X64

set MINGW=C:\mingw32\bin
if not exist "%MINGW%\g++.exe" (
  echo ERROR: C:\mingw32\bin\g++.exe was not found.
  exit /b 1
)
set OUT=%ROOT%release-x86
if not exist "%OUT%" mkdir "%OUT%"
set PATH=%MINGW%;%PATH%
g++ -std=c++11 -I"%ROOT%compiler\include" -I"%ROOT%runtime\include" "%ROOT%compiler\src\main.cpp" "%ROOT%compiler\src\compiler.cpp" "%ROOT%compiler\src\token.cpp" "%ROOT%compiler\src\diagnostics.cpp" "%ROOT%compiler\src\codegen.cpp" "%ROOT%compiler\src\ast.cpp" "%ROOT%compiler\src\parser.cpp" "%ROOT%compiler\src\lexer.cpp" "%ROOT%compiler\src\web.cpp" "%ROOT%compiler\src\app.cpp" "%ROOT%runtime\src\runtime.cpp" -o "%OUT%\nexa.exe"
if errorlevel 1 exit /b 1
if exist "%ROOT%assets\nexa-file.ico" copy /Y "%ROOT%assets\nexa-file.ico" "%OUT%\nexa-file.ico" >nul
"%OUT%\nexa.exe" version
exit /b %errorlevel%

:X64
set MINGW=C:\mingw64\bin
if not exist "%MINGW%\g++.exe" (
  echo ERROR: C:\mingw64\bin\g++.exe was not found.
  echo Install a 64-bit MinGW toolchain before building the x64 release.
  exit /b 1
)
set OUT=%ROOT%release-x64
if not exist "%OUT%" mkdir "%OUT%"
set PATH=%MINGW%;%PATH%
g++ -std=c++11 -I"%ROOT%compiler\include" -I"%ROOT%runtime\include" "%ROOT%compiler\src\main.cpp" "%ROOT%compiler\src\compiler.cpp" "%ROOT%compiler\src\token.cpp" "%ROOT%compiler\src\diagnostics.cpp" "%ROOT%compiler\src\codegen.cpp" "%ROOT%compiler\src\ast.cpp" "%ROOT%compiler\src\parser.cpp" "%ROOT%compiler\src\lexer.cpp" "%ROOT%compiler\src\web.cpp" "%ROOT%compiler\src\app.cpp" "%ROOT%runtime\src\runtime.cpp" -o "%OUT%\nexa.exe"
if errorlevel 1 exit /b 1
if exist "%ROOT%assets\nexa-file.ico" copy /Y "%ROOT%assets\nexa-file.ico" "%OUT%\nexa-file.ico" >nul
"%OUT%\nexa.exe" version
exit /b %errorlevel%
