NexaW 0.9.1

NexaW is Nexa's lightweight web source format. Files use the .nxw extension.
The Nexa compiler turns a .nxw file into standalone HTML.

Build:
  nexa web site.nxw site.html

If the output path is omitted, Nexa replaces .nxw with .html.

Basic commands:
  page "My Site"
  lang "en"
  style "body { font-family: sans-serif; }"
  h1 "Hello"
  h2 "Section"
  h3 "Small heading"
  p "Paragraph"
  small "Small text"
  link "Nexa" "https://example.com"
  raw "<hr>"
  end

Comments begin with #.
Quoted strings support \\n, \\t, \\" and \\\\.
