#ifndef NEXA_RUNTIME_HPP
#define NEXA_RUNTIME_HPP

#include <map>
#include <string>
#include <vector>

namespace nexa {

class Value {
public:
    enum class Type {
        Null,
        Number,
        String,
        Boolean,
        List
    };

    Value();

    static Value null();
    static Value number(double value);
    static Value string(const std::string& value);
    static Value boolean(bool value);
    static Value list(
        const std::vector<Value>& value
    );

    Type type() const;

    double toNumber() const;
    const std::string& toString() const;
    bool toBoolean() const;

    const std::vector<Value>& toList() const;
    std::vector<Value>& toList();

    Value index(size_t index) const;

    bool isNull() const;

private:
    Type valueType;

    double numberData;
    std::string stringData;
    bool booleanData;
    std::vector<Value> listData;
};

class Environment {
public:
    explicit Environment(
        Environment* parent = 0
    );

    void set(
        const std::string& name,
        const Value& value
    );

    Value get(
        const std::string& name
    ) const;

    void assign(
        const std::string& name,
        const Value& value
    );

    bool has(
        const std::string& name
    ) const;

private:
    Environment* parent;
    std::map<std::string, Value> values;
};

bool truthy(const Value& value);

void print(const Value& value);

Value length(const Value& value);

Value typeOf(const Value& value);

long long repeatCount(const Value& value);

Value operator+(
    const Value& a,
    const Value& b
);

Value operator-(
    const Value& a,
    const Value& b
);

Value operator*(
    const Value& a,
    const Value& b
);

Value operator/(
    const Value& a,
    const Value& b
);

Value operator%(
    const Value& a,
    const Value& b
);

Value operator==(
    const Value& a,
    const Value& b
);

Value operator!=(
    const Value& a,
    const Value& b
);

Value operator<(
    const Value& a,
    const Value& b
);

Value operator<=(
    const Value& a,
    const Value& b
);

Value operator>(
    const Value& a,
    const Value& b
);

Value operator>=(
    const Value& a,
    const Value& b
);

}

#endif