#include "nexa/runtime.hpp"

#include <cmath>
#include <iostream>
#include <sstream>
#include <stdexcept>

namespace nexa {

Value::Value()
    : valueType(Type::Null),
      numberData(0.0),
      booleanData(false) {
}

Value Value::null() {
    return Value();
}

Value Value::number(double value) {
    Value result;

    result.valueType = Type::Number;
    result.numberData = value;

    return result;
}

Value Value::string(const std::string& value) {
    Value result;

    result.valueType = Type::String;
    result.stringData = value;

    return result;
}

Value Value::boolean(bool value) {
    Value result;

    result.valueType = Type::Boolean;
    result.booleanData = value;

    return result;
}

Value Value::list(
    const std::vector<Value>& value
) {
    Value result;

    result.valueType = Type::List;
    result.listData = value;

    return result;
}

Value::Type Value::type() const {
    return valueType;
}

double Value::toNumber() const {
    if (valueType != Type::Number) {
        throw std::runtime_error(
            "Value is not a number."
        );
    }

    return numberData;
}

const std::string& Value::toString() const {
    if (valueType != Type::String) {
        throw std::runtime_error(
            "Value is not a string."
        );
    }

    return stringData;
}

bool Value::toBoolean() const {
    if (valueType != Type::Boolean) {
        throw std::runtime_error(
            "Value is not a boolean."
        );
    }

    return booleanData;
}

const std::vector<Value>& Value::toList() const {
    if (valueType != Type::List) {
        throw std::runtime_error(
            "Value is not a list."
        );
    }

    return listData;
}

std::vector<Value>& Value::toList() {
    if (valueType != Type::List) {
        throw std::runtime_error(
            "Value is not a list."
        );
    }

    return listData;
}

Value Value::index(size_t index) const {
    if (valueType != Type::List) {
        throw std::runtime_error(
            "Only lists can be indexed."
        );
    }

    if (index >= listData.size()) {
        throw std::runtime_error(
            "List index out of range."
        );
    }

    return listData[index];
}

bool Value::isNull() const {
    return valueType == Type::Null;
}

Environment::Environment(
    Environment* parent
)
    : parent(parent) {
}

void Environment::set(
    const std::string& name,
    const Value& value
) {
    values[name] = value;
}

Value Environment::get(
    const std::string& name
) const {
    std::map<std::string, Value>::const_iterator it =
        values.find(name);

    if (it != values.end()) {
        return it->second;
    }

    if (parent != 0) {
        return parent->get(name);
    }

    throw std::runtime_error(
        "Undefined variable: " + name
    );
}

void Environment::assign(
    const std::string& name,
    const Value& value
) {
    std::map<std::string, Value>::iterator it =
        values.find(name);

    if (it != values.end()) {
        it->second = value;
        return;
    }

    if (parent != 0 && parent->has(name)) {
        parent->assign(name, value);
        return;
    }

    throw std::runtime_error(
        "Undefined variable: " + name
    );
}

bool Environment::has(
    const std::string& name
) const {
    if (values.find(name) != values.end()) {
        return true;
    }

    return parent != 0 && parent->has(name);
}

bool truthy(const Value& value) {
    switch (value.type()) {
        case Value::Type::Null:
            return false;

        case Value::Type::Boolean:
            return value.toBoolean();

        case Value::Type::Number:
            return value.toNumber() != 0.0;

        case Value::Type::String:
            return !value.toString().empty();

        case Value::Type::List:
            return !value.toList().empty();
    }

    return false;
}

static void printInline(const Value& value) {
    switch (value.type()) {
        case Value::Type::Null:
            std::cout << "null";
            break;

        case Value::Type::Number: {
            double n = value.toNumber();

            if (std::floor(n) == n) {
                std::cout << static_cast<long long>(n);
            } else {
                std::cout << n;
            }

            break;
        }

        case Value::Type::String:
            std::cout << value.toString();
            break;

        case Value::Type::Boolean:
            std::cout <<
                (value.toBoolean() ? "true" : "false");
            break;

        case Value::Type::List: {
            std::cout << "[";

            const std::vector<Value>& values =
                value.toList();

            for (size_t i = 0; i < values.size(); ++i) {
                if (i != 0) {
                    std::cout << ", ";
                }

                printInline(values[i]);
            }

            std::cout << "]";
            break;
        }
    }
}

void print(const Value& value) {
    printInline(value);
    std::cout << std::endl;
}

Value length(const Value& value) {
    if (value.type() == Value::Type::String) {
        return Value::number(
            static_cast<double>(
                value.toString().size()
            )
        );
    }

    if (value.type() == Value::Type::List) {
        return Value::number(
            static_cast<double>(
                value.toList().size()
            )
        );
    }

    throw std::runtime_error(
        "length() expects a string or list."
    );
}

Value typeOf(const Value& value) {
    switch (value.type()) {
        case Value::Type::Null:
            return Value::string("null");

        case Value::Type::Number:
            return Value::string("number");

        case Value::Type::String:
            return Value::string("string");

        case Value::Type::Boolean:
            return Value::string("boolean");

        case Value::Type::List:
            return Value::string("list");
    }

    return Value::string("unknown");
}

long long repeatCount(const Value& value) {
    if (value.type() != Value::Type::Number) {
        throw std::runtime_error(
            "repeat expects a number."
        );
    }

    double n = value.toNumber();

    if (!std::isfinite(n) || n < 0.0 || std::floor(n) != n) {
        throw std::runtime_error(
            "repeat expects a non-negative integer."
        );
    }

    return static_cast<long long>(n);
}

Value operator+(
    const Value& a,
    const Value& b
) {
    if (a.type() == Value::Type::String ||
        b.type() == Value::Type::String) {

        std::string left;
        std::string right;

        if (a.type() == Value::Type::String) {
            left = a.toString();
        } else {
            std::ostringstream stream;
            stream << a.toNumber();
            left = stream.str();
        }

        if (b.type() == Value::Type::String) {
            right = b.toString();
        } else {
            std::ostringstream stream;
            stream << b.toNumber();
            right = stream.str();
        }

        return Value::string(left + right);
    }

    return Value::number(
        a.toNumber() + b.toNumber()
    );
}

Value operator-(
    const Value& a,
    const Value& b
) {
    return Value::number(
        a.toNumber() - b.toNumber()
    );
}

Value operator*(
    const Value& a,
    const Value& b
) {
    return Value::number(
        a.toNumber() * b.toNumber()
    );
}

Value operator/(
    const Value& a,
    const Value& b
) {
    if (b.toNumber() == 0.0) {
        throw std::runtime_error(
            "Division by zero."
        );
    }

    return Value::number(
        a.toNumber() / b.toNumber()
    );
}

Value operator%(
    const Value& a,
    const Value& b
) {
    if (b.toNumber() == 0.0) {
        throw std::runtime_error(
            "Modulo by zero."
        );
    }

    return Value::number(
        std::fmod(
            a.toNumber(),
            b.toNumber()
        )
    );
}

Value operator==(
    const Value& a,
    const Value& b
) {
    if (a.type() != b.type()) {
        return Value::boolean(false);
    }

    switch (a.type()) {
        case Value::Type::Null:
            return Value::boolean(true);

        case Value::Type::Number:
            return Value::boolean(
                a.toNumber() == b.toNumber()
            );

        case Value::Type::String:
            return Value::boolean(
                a.toString() == b.toString()
            );

        case Value::Type::Boolean:
            return Value::boolean(
                a.toBoolean() == b.toBoolean()
            );

        case Value::Type::List:
            return Value::boolean(
                a.toList().size() ==
                b.toList().size()
            );
    }

    return Value::boolean(false);
}

Value operator!=(
    const Value& a,
    const Value& b
) {
    return Value::boolean(
        !truthy(operator==(a, b))
    );
}

Value operator<(
    const Value& a,
    const Value& b
) {
    return Value::boolean(
        a.toNumber() < b.toNumber()
    );
}

Value operator<=(
    const Value& a,
    const Value& b
) {
    return Value::boolean(
        a.toNumber() <= b.toNumber()
    );
}

Value operator>(
    const Value& a,
    const Value& b
) {
    return Value::boolean(
        a.toNumber() > b.toNumber()
    );
}

Value operator>=(
    const Value& a,
    const Value& b
) {
    return Value::boolean(
        a.toNumber() >= b.toNumber()
    );
}

}