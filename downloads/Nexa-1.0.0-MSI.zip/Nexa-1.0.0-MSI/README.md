#  Nexa 1.0.0 MSI 

## Dont Delete or remove cb1 or the installtion will not work.

### And enjoy your Nexa 


create and learn.